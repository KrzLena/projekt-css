﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace app
{
    public partial class Uczen : Window
    {
        public bool IsConfirmed { get; private set; } = false;
        private bool isEditMode = false;

        public Uczen()
        {
            InitializeComponent();
            AddButton.Content = "Dodaj";
        }

        public Uczen(MainWindow.Osoba osoba) : this()
        {
            isEditMode = true;
            AddButton.Content = "Zapisz";

            pPesel.Text = osoba.m_strPESEL;
            pName.Text = osoba.m_strName;
            pSname.Text = osoba.m_strSurname;

            if (DateTime.TryParse(osoba.m_strBirthDate, out DateTime birthDate))
            {
                pDate.SelectedDate = birthDate;
            }

            pAdres.Text = osoba.m_strAdres;
            pCity.Text = osoba.m_strCity;
            pPost.Text = osoba.m_strPost;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateFields())
                return;

            string message = isEditMode ?
                "Czy na pewno chcesz zapisać zmiany?" :
                "Czy na pewno chcesz dodać nowego ucznia?";

            if (MessageBox.Show(message, "Potwierdzenie", MessageBoxButton.OKCancel, MessageBoxImage.Question) == MessageBoxResult.OK)
            {
                IsConfirmed = true;
                this.Close();
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            if (HasUnsavedChanges())
            {
                if (MessageBox.Show("Czy na pewno chcesz anulować? Wprowadzone zmiany zostaną utracone.",
                    "Potwierdzenie",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning) == MessageBoxResult.No)
                {
                    return;
                }
            }
            this.Close();
        }

        private bool HasUnsavedChanges()
        {
            return !string.IsNullOrWhiteSpace(pPesel.Text) ||
                   !string.IsNullOrWhiteSpace(pName.Text) ||
                   !string.IsNullOrWhiteSpace(pSname.Text) ||
                   !string.IsNullOrWhiteSpace(pAdres.Text) ||
                   !string.IsNullOrWhiteSpace(pCity.Text) ||
                   !string.IsNullOrWhiteSpace(pPost.Text) ||
                   pDate.SelectedDate != null;
        }

        private bool ValidateFields()
        {
            bool isValid = true;
            Brush errorBrush = Brushes.Red;

            // Resetowanie wyglądu pól
            pPesel.BorderBrush = Brushes.Gray;
            pName.BorderBrush = Brushes.Gray;
            pSname.BorderBrush = Brushes.Gray;
            pAdres.BorderBrush = Brushes.Gray;
            pCity.BorderBrush = Brushes.Gray;
            pPost.BorderBrush = Brushes.Gray;
            pDate.BorderBrush = Brushes.Gray;

            // Formatowanie danych
            pPesel.Text = pPesel.Text.Trim();
            pName.Text = FormatName(pName.Text);
            pSname.Text = FormatName(pSname.Text);
            pAdres.Text = FormatAddress(pAdres.Text);
            pCity.Text = FormatName(pCity.Text);
            pPost.Text = pPost.Text.Trim();

            // Walidacja PESEL
            if (string.IsNullOrWhiteSpace(pPesel.Text) || !ValidatePESEL(pPesel.Text, pDate.SelectedDate))
            {
                pPesel.BorderBrush = errorBrush;
                isValid = false;
            }

            // Walidacja imienia
            if (string.IsNullOrWhiteSpace(pName.Text))
            {
                pName.BorderBrush = errorBrush;
                isValid = false;
            }

            // Walidacja nazwiska
            if (string.IsNullOrWhiteSpace(pSname.Text))
            {
                pSname.BorderBrush = errorBrush;
                isValid = false;
            }

            // Walidacja daty urodzenia
            if (pDate.SelectedDate == null)
            {
                pDate.BorderBrush = errorBrush;
                isValid = false;
            }

            // Walidacja adresu
            if (string.IsNullOrWhiteSpace(pAdres.Text))
            {
                pAdres.BorderBrush = errorBrush;
                isValid = false;
            }

            // Walidacja miejscowości
            if (string.IsNullOrWhiteSpace(pCity.Text))
            {
                pCity.BorderBrush = errorBrush;
                isValid = false;
            }

            // Walidacja kodu pocztowego
            if (string.IsNullOrWhiteSpace(pPost.Text) || !Regex.IsMatch(pPost.Text, @"^\d{2}-\d{3}$"))
            {
                pPost.BorderBrush = errorBrush;
                isValid = false;
            }

            if (!isValid)
            {
                MessageBox.Show("Proszę poprawić zaznaczone pola.", "Błąd walidacji", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            return isValid;
        }

        private string FormatName(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return input;
            input = input.Trim();
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(input.ToLower());
        }

        private string FormatAddress(string input)
        {
            return Regex.Replace(input.Trim(), @"\s+", " ");
        }

        private bool ValidatePESEL(string pesel, DateTime? birthDate)
        {
            if (string.IsNullOrWhiteSpace(pesel) || pesel.Length != 11 || !Regex.IsMatch(pesel, @"^\d{11}$"))
                return false;

            int[] weights = { 1, 3, 7, 9, 1, 3, 7, 9, 1, 3 };
            int sum = 0;

            for (int i = 0; i < weights.Length; i++)
            {
                sum += weights[i] * (pesel[i] - '0');
            }

            int controlDigit = (10 - (sum % 10)) % 10;
            if (controlDigit != (pesel[10] - '0'))
                return false;

            if (birthDate != null)
            {
                int year = birthDate.Value.Year % 100;
                int month = birthDate.Value.Month;
                int day = birthDate.Value.Day;
                int peselYear = int.Parse(pesel.Substring(0, 2));
                int peselMonth = int.Parse(pesel.Substring(2, 2));
                int peselDay = int.Parse(pesel.Substring(4, 2));

                int century = birthDate.Value.Year / 100;
                int expectedMonth = month;
                if (century == 19) expectedMonth += 0;
                else if (century == 20) expectedMonth += 20;
                else if (century == 21) expectedMonth += 40;
                else if (century == 22) expectedMonth += 60;
                else if (century == 18) expectedMonth += 80;

                if (peselYear != year || peselMonth != expectedMonth || peselDay != day)
                    return false;
            }

            return true;
        }

        public string PESEL => pPesel.Text;
        public string Name => pName.Text;
        public string Surname => pSname.Text;
        public string Adres => pAdres.Text;
        public string City => pCity.Text;
        public string Post => pPost.Text;
        public string Date => pDate.SelectedDate?.ToString("yyyy-MM-dd") ?? "";
    }
}
﻿using Microsoft.Win32;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace app
{
    public partial class MainWindow : Window
    {
        public class Osoba
        {
            public string m_strPESEL { get; set; }
            public string m_strName { get; set; }
            public string m_strSurname { get; set; }
            public string m_strBirthDate { get; set; }
            public string m_strAdres { get; set; }
            public string m_strCity { get; set; }
            public string m_strPost { get; set; }

            public Osoba()
            {
                m_strPESEL = "";
                m_strName = "";
                m_strSurname = "";
                m_strBirthDate = "";
                m_strAdres = "";
                m_strCity = "";
                m_strPost = "";
            }
        }

        public MainWindow()
        {
            InitializeComponent();
        }

        private void New_Click(object sender, RoutedEventArgs e)
        {
            mainList.Items.Clear();
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Pliki CSV z separatorem (,) |*.csv|Pliki CSV z separatorem (;) |*.csv";
            openFileDialog.Title = "Otwórz plik CSV";

            if (openFileDialog.ShowDialog() == true)
            {
                mainList.Items.Clear();
                string filePath = openFileDialog.FileName;
                int selectedFilterIndex = openFileDialog.FilterIndex;
                string delimiter = selectedFilterIndex == 1 ? "," : ";";
                Encoding encoding = Encoding.UTF8;

                if (File.Exists(filePath))
                {
                    var lines = File.ReadAllLines(filePath, encoding);
                    foreach (var line in lines)
                    {
                        string[] columns = line.Split(delimiter);
                        if (columns.Length >= 8)
                        {
                            Osoba uczen = new()
                            {
                                m_strPESEL = columns[0],
                                m_strName = columns[1],
                                m_strSurname = columns[3],
                                m_strBirthDate = columns[4],
                                m_strAdres = columns[5],
                                m_strCity = columns[6],
                                m_strPost = columns[7]
                            };
                            mainList.Items.Add(uczen);
                        }
                    }
                }
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Pliki CSV z separatorem (,) |*.csv|Pliki CSV z separatorem (;) |*.csv";
            saveFileDialog.Title = "Zapisz plik CSV";

            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                string delimiter = saveFileDialog.FilterIndex == 1 ? "," : ";";

                using StreamWriter writer = new(filePath);
                foreach (Osoba item in mainList.Items)
                {
                    string row = string.Join(delimiter,
                        item.m_strPESEL,
                        item.m_strName,
                        item.m_strSurname,
                        item.m_strBirthDate,
                        item.m_strAdres,
                        item.m_strCity,
                        item.m_strPost);
                    writer.WriteLine(row);
                }
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void RemoveSelected_Click(object sender, RoutedEventArgs e)
        {
            if (mainList.SelectedItems.Count > 0)
            {
                var result = MessageBox.Show("Czy na pewno chcesz usunąć wybrane rekordy?",
                    "Potwierdzenie",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    var selectedItems = mainList.SelectedItems;
                    var itemsToRemove = new System.Collections.ArrayList(selectedItems);

                    foreach (var item in itemsToRemove)
                    {
                        mainList.Items.Remove(item);
                    }
                }
            }
            else
            {
                MessageBox.Show("Wybierz rekordy do usunięcia.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void NewRecord_Click(object sender, RoutedEventArgs e)
        {
            Uczen wnd = new Uczen();
            wnd.Title = "Dodaj nowego ucznia";
            wnd.ShowDialog();

            if (wnd.IsConfirmed)
            {
                Osoba uczen = new()
                {
                    m_strPESEL = wnd.PESEL,
                    m_strName = wnd.Name,
                    m_strSurname = wnd.Surname,
                    m_strBirthDate = wnd.Date,
                    m_strAdres = wnd.Adres,
                    m_strCity = wnd.City,
                    m_strPost = wnd.Post
                };
                mainList.Items.Add(uczen);
            }
        }

        private void EditSelected_Click(object sender, RoutedEventArgs e)
        {
            if (mainList.SelectedItem is Osoba selectedPerson)
            {
                Uczen wnd = new Uczen(selectedPerson);
                wnd.Title = "Edytuj dane ucznia";
                wnd.ShowDialog();

                if (wnd.IsConfirmed)
                {
                    selectedPerson.m_strPESEL = wnd.PESEL;
                    selectedPerson.m_strName = wnd.Name;
                    selectedPerson.m_strSurname = wnd.Surname;
                    selectedPerson.m_strBirthDate = wnd.Date;
                    selectedPerson.m_strAdres = wnd.Adres;
                    selectedPerson.m_strCity = wnd.City;
                    selectedPerson.m_strPost = wnd.Post;

                    // Odświeżenie widoku ListView
                    mainList.Items.Refresh();
                }
            }
            else
            {
                MessageBox.Show("Wybierz osobę do edycji.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
